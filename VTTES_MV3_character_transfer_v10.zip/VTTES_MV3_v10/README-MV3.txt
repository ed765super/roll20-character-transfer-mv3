VTTES Character Transfer - Manifest V3 compatibility build v10

Purpose:
- Export a character from a Roll20 game to VTTES JSON.
- Overwrite an editable character in another Roll20 game from that JSON.

v10 changes:
- Hydrates/refreshes the destination character's attribute and ability collections BEFORE overwrite.
- Verifies the first overwrite pass; if Roll20 only persisted part of the character, automatically rehydrates and retries once.
- Keeps the v9 export hydration and incomplete-export protections for modern D&D builder/store data.
- Keeps destination controlled-by / player-journal permissions.
- Editable Characters now refreshes live when characters are added/removed, renamed, or their control/journal permissions change.
- Refreshes the sidebar again after an overwrite so the imported name appears immediately.
- Retains the 60-second Overwriting-dialog escape hatch and post-import verification summary.
- Keeps this as a focused character-transfer build rather than enabling unrelated legacy VTTES modules.

This is an unofficial local compatibility port.
